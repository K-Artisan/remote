package com.arzirtime.remote.client.ui;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.arzirtime.remote.R;
import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;

public class DeviceActivity extends BaseNavigationActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initView();
    }

    @Override
    int getContentViewId() {
        return R.layout.activity_device;
    }

    @Override
    int getNavigationMenuItemId() {
        return R.id.app_navigation_device;
    }

    public void initView() {
        //折叠布局：CollapsingToolbarLayout
        CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.collapsingToolbarLayout);
        collapsingToolbarLayout.setTitle(" ");

        //使用Toolbar替换系统的ActionBar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            //actionBar.setDisplayHomeAsUpEnabled(true); //启用HomeAsUp按钮，其id永远为：android.R.id.home
        }

        //图片
        ImageView deviceImageView = findViewById(R.id.device_imgview);
        Glide.with(this).load(R.drawable.boot_splash2)
                .placeholder(R.drawable.ads_pic2) //加载中显示d 图片
                //.error(R.drawable.device_default) //异常显示的图片
                //.fallback(R.drawable.device_default) //图片为null时显示的图片
                .centerCrop()
                .into(deviceImageView);

        //文字信息
        TextView textView = findViewById(R.id.tv_device_content);
        textView.setText("123456");

    }
}
