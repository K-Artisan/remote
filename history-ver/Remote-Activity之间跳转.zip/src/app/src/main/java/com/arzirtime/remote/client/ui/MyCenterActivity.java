package com.arzirtime.remote.client.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.arzirtime.remote.R;

public class MyCenterActivity extends BaseNavigationActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    int getContentViewId() {
        return R.layout.activity_my_center;
    }

    @Override
    int getNavigationMenuItemId() {
        return R.id.app_navigation_my_center;
    }
}
