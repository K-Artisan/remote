package com.arzirtime.remote.client.ui;

import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.arzirtime.remote.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;


/**
 * 使用 BottomNavigationView 在 Activity之间进行跳转
 */
public abstract class BaseNavigationActivity extends BaseActivity  {

    protected BottomNavigationView navigationView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getContentViewId());
        initNavigationView();
    }

    protected void initNavigationView() {
        navigationView = (BottomNavigationView) findViewById(R.id.app_navigtion);

        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                navigationView.postDelayed(() -> {
                    int itemId = item.getItemId();
                    if (itemId == R.id.app_navigation_device) {


                        startActivity(new Intent(BaseNavigationActivity.this, DeviceActivity.class));
                    } else if (itemId == R.id.app_navigation_smart) {
                        startActivity(new Intent(BaseNavigationActivity.this, SmartActivity.class));
                    } else if (itemId == R.id.app_navigation_my_center) {
                        startActivity(new Intent(BaseNavigationActivity.this, MyCenterActivity.class));
                    }

                    finish();

                }, 300);


                return true;
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        updateNavigationBarState();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Remove inter-activity transition to avoid screen tossing on tapping bottom navigation items
        overridePendingTransition(0, 0);
    }
    
    //Activity切换无动画
    private void jumpWhitNoAnimation(){
        // Remove inter-activity transition to avoid screen tossing on tapping bottom navigation items
        overridePendingTransition(0,0);
    }

    private void updateNavigationBarState() {
        int actionId = getNavigationMenuItemId();
        selectBottomNavigationBarItem(actionId);
    }

    void selectBottomNavigationBarItem(int itemId) {
        MenuItem item = navigationView.getMenu().findItem(itemId);
        item.setChecked(true);
    }

    abstract int getContentViewId();

    abstract int getNavigationMenuItemId();
}
