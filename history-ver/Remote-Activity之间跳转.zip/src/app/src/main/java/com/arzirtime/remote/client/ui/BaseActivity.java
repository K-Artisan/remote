package com.arzirtime.remote.client.ui;

import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.arzirtime.remote.client.receiver.ForceOfflineReceiver;
import com.arzirtime.remote.client.receiver.NetWorkChangeReciever;
import com.arzirtime.remote.client.ui.ActivityManager;
import com.arzirtime.remote.common.AppConstanct;

/**
 * Activity的基础类
 */
public class BaseActivity extends AppCompatActivity {

    private ForceOfflineReceiver forceOfflineReceiver;
    private NetWorkChangeReciever netWorkChangeReciever;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityManager.addActivity(this);
    }

    /**
     * 前台生存期 。活动在 onResume() 方法和 onPause()方法之间所经历的就是前台生存期。在前台生存期内，
     * 活动总是处于运行状态的，此时的活动是可以和用户进行交互的，我们平时看到和接触最多的也就是这个状态下的活动
     */
    @Override
    protected void onResume() {
        super.onResume();

        /*--------------------------------------------------
         活动进入活动栈顶端，注册广播接收器
        * -------------------------------------------------*/

        //注册网络播接收器:强制下线
        IntentFilter ifOffline = new IntentFilter();
        ifOffline.addAction(AppConstanct.BROADCAST_FORCE_OFFLINE);
        forceOfflineReceiver = new ForceOfflineReceiver();
        registerReceiver(forceOfflineReceiver, ifOffline);

        //注册广播接收器：网络变化，当网络变化时系统发送该广播
        IntentFilter ifNetwork = new IntentFilter();
        ifNetwork.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        netWorkChangeReciever = new NetWorkChangeReciever();
        registerReceiver(netWorkChangeReciever, ifNetwork);
    }

    /**
     * 前台生存期 。活动在 onResume() 方法和 onPause()方法之间所经历的就是前台生存期。在前台生存期内，
     * 活动总是处于运行状态的，此时的活动是可以和用户进行交互的，我们平时看到和接触最多的也就是这个状态下的活动
     */
    @Override
    protected void onPause() {
        super.onPause();

        /*--------------------------------------------------
         活动离开活动栈顶端，注销广播接收器
        * -------------------------------------------------*/
        if (forceOfflineReceiver != null) {
            unregisterReceiver(forceOfflineReceiver); //注销广播接收器
            forceOfflineReceiver = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        ActivityManager.removeActivity(this);
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        //按返回键，程序进入后台运行，不关闭程序
        moveTaskToBack(true);
    }

    /**
     * onConfigurationChanged
     * * the package:android.content.res.Configuration.
     * * @param newConfig, The new device configuration.
     * * 当设备配置信息有改动（比如屏幕方向的改变，实体键盘的推开或合上等）时，
     * * 并且如果此时有activity正在运行，系统会调用这个函数。
     * * 注意：onConfigurationChanged只会监测应用程序在AnroidMainifest.xml中通过
     * * android:configChanges="xxxx"指定的配置类型的改动；
     * * 而对于其他配置的更改，则系统会onDestroy()当前Activity，然后重启一个新的Activity实例。
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //检测屏幕的方向：纵向或横向
        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            //当前为横屏， 在此处添加额外的处理代码
        } else if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            //当前为竖屏， 在此处添加额外的处理代码                }
            //检测实体键盘的状态：推出或者合上
            if (newConfig.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_NO) {
                //实体键盘处于推出状态，在此处添加额外的处理代码
            } else if (newConfig.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES) {
                // 实体键盘处于合上状态，在此处添加额外的处理代码
            }
        }
    }
}