package com.arzirtime.remote.client.adapter;

public class DeviceAdapter {
}
