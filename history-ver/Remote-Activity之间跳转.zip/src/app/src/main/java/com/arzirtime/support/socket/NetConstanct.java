package com.arzirtime.support.socket;

public class NetConstanct {
    public static final int SOCKET_TIMEOUT = 3000; //ms
}
