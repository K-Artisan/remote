package com.arzirtime.support.socket;


/**
 * 心跳线程
 * */
public class TcpHeartBeatThread extends Thread {

}
