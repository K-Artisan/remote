package com.arzirtime.remote.db.entity;

public class Device {
}
