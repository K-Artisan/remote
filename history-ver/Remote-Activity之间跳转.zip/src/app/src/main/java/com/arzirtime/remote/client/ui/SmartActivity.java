package com.arzirtime.remote.client.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.arzirtime.remote.R;

public class SmartActivity extends BaseNavigationActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    int getContentViewId() {
        return R.layout.activity_smart;
    }

    @Override
    int getNavigationMenuItemId() {
        return R.id.app_navigation_smart;
    }
}
