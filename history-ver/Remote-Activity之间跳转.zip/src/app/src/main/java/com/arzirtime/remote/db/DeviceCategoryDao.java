package com.arzirtime.remote.db;

public class DeviceCategoryDao {
}
