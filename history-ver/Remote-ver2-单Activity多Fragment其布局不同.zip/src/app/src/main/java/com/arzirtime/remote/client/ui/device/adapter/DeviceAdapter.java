package com.arzirtime.remote.client.ui.device.adapter;

public class DeviceAdapter {
}
