package com.arzirtime.remote.common;

/**
 * App用到的常量
 * */
public class AppConstanct {

    //强制下线广播常量
    public final  static String BROADCAST_FORCE_OFFLINE = "com.arzirtime.iremoter.BROADCAST_FORCE_OFFLINE";
    public final  static String CONNECTCLIENTID = "CONNECTCLIENTID";
}
