package com.arzirtime.remote.service;

public class DeviceService {
}
