package com.arzirtime.remote.db;

public class DeviceDao {
}
