package com.arzirtime.remote.dto;

public class DeviceDto {
}
